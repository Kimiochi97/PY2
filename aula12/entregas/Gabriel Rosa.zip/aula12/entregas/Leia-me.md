Criar uma pasta aqui com nome do aluno para entrega

* Ao tentar fazer o push (envio) das alterações, não será permitido devido o repositório não ser do aluno, Utilize o GIT Desktop ao fazer o push ele vai perguntar se quer fazer o fork (copia do repo na sua conta), diga que sim.

Agora entre no site github.com, vc estará um commit a frente e aparecerá um botão criar "Pull Resquest"